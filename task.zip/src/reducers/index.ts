import loginReducer from './loginReducer';

export {
  loginReducer
};