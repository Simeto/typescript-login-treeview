const initialState = {
  login: {
    username: '',
    password: '',
    isLoading: false,
    isLogged: false,
    error: ''
  }
}

export default initialState