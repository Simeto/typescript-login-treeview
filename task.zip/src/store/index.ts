import initialState from './store'

export {
  initialState
}