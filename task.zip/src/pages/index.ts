import Login from './Login';
import Checkboxes from './Checkboxes';
import ErrorPage from './ErrorPage';

export {
  Login,
  Checkboxes,
  ErrorPage
}