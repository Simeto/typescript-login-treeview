import * as user from './userMutations';

const mutations =  {
  user
};

export default mutations;