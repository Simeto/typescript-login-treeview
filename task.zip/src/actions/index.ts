import * as users from './userActions';

const actions = {
  users
}

export default actions;